Neeval Kumar 011877086 Mac OS 64 bit. I used terminal to compile.

Everything works good. 

I tested 
./p4 "Frank Butt" 0 
./p4 "Frank Butt" 0 1 5

which matches the output during lecture

I also tested 
./p4 "aMVIF wPOO" 1 1 5 

which is the encryption of the second Frank Butt statement, and made it decrypt back into Frank Butt.