/*
   File - key3.h
   Encryption attributes for program #4
*/

long direction  = 0;  /* 0 means forward, 1 means backward */
long shiftcount = 2;  /* number of character to shift */


