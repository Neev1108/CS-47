Everything works as intended. Just use the p2test.out commands for the command line. 

To compile:

gcc -o p2 p2.cpp